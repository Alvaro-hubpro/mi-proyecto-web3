import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import PageLoader from "./components/PageLoader";
import SeoMeta from "./components/SeoMeta";
import { ThemeProvider } from "./contexts/ThemeContext";
import "./page-loader.css";
import Home from "./pages/Home";
import Gallery from "./pages/Gallery";
import Terraza360 from "./pages/Terraza360";


function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/terraza-360"} component={Terraza360} />
      <Route path={"/galeria"} component={Gallery} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <PageLoader />
          <SeoMeta />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
